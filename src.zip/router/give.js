import View from '@/views/give/give'

export default [
  {
    path: '/give',
    component: View
  }
]
