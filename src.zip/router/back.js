import View from '@/views/back/back'

export default [
  {
    path: '/back',
    component: View
  }
]
