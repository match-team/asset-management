import View from '@/views/scrap/index'

export default [
  {
    path: '/scrap',
    component: View
  }
]
