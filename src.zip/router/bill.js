import View from '@/views/bill/bill'

export default [
  {
    path: '/bill',
    component: View
  }
]
