import View from '@/views/login/login'

export default [
  {
    path: '/login',
    component: View
  }
]
