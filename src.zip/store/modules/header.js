export default {
  namespaced: true,
  state: {
    breadcrumb: {}
  },
  mutations: {
    saveHeader(state, value) {
      console.log(value)
    }
  },
  actions: {}
}
