import PlatformLayout from '@/views/home/index'

export default [
  {
    path: '/platform',
    component: PlatformLayout
  }
]
