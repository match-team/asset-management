import platform from './platform'

export default [
  {
    path: '/',
    redirect: '/platform'
  },

  ...platform
]
